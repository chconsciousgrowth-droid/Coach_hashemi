# HTTPS برای PWA کوچ هاشمی

PWA فقط روی **HTTPS** (یا localhost) قابل نصب است.

---

## ۱) تست محلی (الان)

```bash
cd server
python3 app.py
```

اگر `certs/cert.pem` و `certs/key.pem` باشند، سرور روی HTTPS بالا می‌آید:

- https://localhost:5000/
- در مرورگر: Advanced → Proceed to localhost (گواهی خودامضا)

خاموش کردن HTTPS محلی:
```bash
USE_HTTPS=0 python3 app.py
```

---

## ۲) سرور واقعی (توصیه)

### روش A — Caddy (ساده‌ترین، HTTPS خودکار)

```bash
# نصب Caddy سپس:
caddy reverse-proxy --from yourdomain.com --to localhost:5000
```

یا `Caddyfile`:
```
yourdomain.com {
    reverse_proxy localhost:5000
}
```

### روش B — Nginx + Let's Encrypt

```bash
sudo apt install nginx certbot python3-certbot-nginx
sudo certbot --nginx -d yourdomain.com
```

نمونه Nginx:
```nginx
server {
    listen 443 ssl;
    server_name yourdomain.com;
    ssl_certificate     /etc/letsencrypt/live/yourdomain.com/fullchain.pem;
    ssl_certificate_key /etc/letsencrypt/live/yourdomain.com/privkey.pem;

    location / {
        proxy_pass http://127.0.0.1:5000;
        proxy_set_header Host $host;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_set_header X-Forwarded-For $remote_addr;
    }
}
```

### روش C — پلتفرم‌های ابری (HTTPS رایگان خودکار)

| سرویس | کار |
|--------|-----|
| **Render** | دامنه رایگان `*.onrender.com` + HTTPS |
| **Railway** | همین‌طور |
| **Fly.io** | همین‌طور |
| **Netlify** | فقط فرانت؛ API جدا |
| **Cloudflare Tunnel** | HTTPS بدون باز کردن پورت |

---

## ۳) بعد از HTTPS

1. سایت را با `https://yourdomain.com` باز کنید  
2. اندروید: بنر «نصب اپ»  
3. آیفون Safari: Share → Add to Home Screen  

---

## امنیت گواهی محلی

`certs/` فقط برای تست است. در production از Let's Encrypt یا گواهی پلتفرم استفاده کنید و `certs/` را در git قرار ندهید.
