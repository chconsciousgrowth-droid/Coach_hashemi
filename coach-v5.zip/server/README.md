# CoachHashemi – Backend (SQLite + Flask)

## اجرای محلی

```bash
cd server
python3 app.py
```

سپس باز کنید:
- سایت: http://localhost:5000/
- پنل ادمین: http://localhost:5000/admin.html
- رمز: `coach2026`

## ساختار دیتابیس

فایل: `coachhashemi.db` (SQLite)

| جدول | کاربرد |
|------|--------|
| settings | تنظیمات سایت، محتوا، بخش‌ها، تم |
| bookings | درخواست‌های رزرو |
| slots | زمان‌های آزاد جلسات |
| admin | رمز عبور و توکن احراز هویت |

## API

| متد | مسیر | توضیح |
|-----|------|-------|
| GET | /api/health | وضعیت سرور |
| POST | /api/login | ورود ادمین |
| GET | /api/config | دریافت تنظیمات (عمومی) |
| PUT | /api/config | ذخیره تنظیمات (نیاز به توکن) |
| GET | /api/bookings | لیست رزروها |
| POST | /api/bookings | ثبت رزرو جدید (عمومی) |
| PATCH | /api/bookings/:id/status | تغییر وضعیت |
| GET/POST/DELETE | /api/slots | مدیریت زمان‌ها |
| PUT | /api/password | تغییر رمز |

## استقرار روی سرور واقعی

### گزینه ۱: Render / Railway
1. ریپو بسازید و این پوشه را push کنید
2. Build: `pip install flask flask-cors`
3. Start: `python server/app.py`
4. متغیر PORT خودکار ست می‌شود

### گزینه ۲: VPS با Nginx
```bash
pip install flask flask-cors gunicorn
gunicorn -b 0.0.0.0:5000 server.app:app
```

### گزینه ۳: ارتقا به PostgreSQL
در صورت نیاز می‌توانید `sqlite3` را با `psycopg2` و PostgreSQL جایگزین کنید.
## HTTPS / PWA

جزئیات کامل در فایل `HTTPS.md`

تست محلی با گواهی خودامضا:
```bash
python3 app.py
# → https://localhost:5000
```
