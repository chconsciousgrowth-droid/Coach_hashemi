کوچ هاشمی — فایل‌های پروژه

محتویات:
- index.html          صفحه اصلی سایت / اپ
- admin.html          پنل مدیریت
- ch-data.js          منطق برنامه
- sw.js + manifest + آیکون‌ها   برای نصب PWA
- server/             سرور، دیتابیس، API
  - app.py
  - requirements.txt
  - README.md
  - HTTPS.md
  - PAY-SMS-GUIDE.md

مراحل بعدی (خلاصه):
1) این زیپ را از حالت فشرده خارج کنید
2) فایل‌ها را در GitHub آپلود کنید
3) در Render.com به ریپو وصل کنید و Deploy بزنید
4) لینک نهایی را روی گوشی باز کنید و اپ را نصب کنید

رمز پنل ادمین پیش‌فرض: coach2026
