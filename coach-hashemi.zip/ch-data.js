
// CoachHashemi Shared Data Layer — supports API (real DB) + localStorage fallback
const CH = {
  API: (typeof location !== "undefined" && location.port === "5000")
    ? ""  // same origin when served by Flask
    : (typeof location !== "undefined" && location.hostname === "localhost"
        ? "http://localhost:5000"
        : ""),  // production: same origin if reverse-proxied

  token: null,

  defaultConfig: {
    site: {
      brandName: "کوچ هاشمی",
      tagline: "Conscious Growth",
      heroTitle: "همراه شما در مسیر",
      heroHighlight: "رشد و تحول فردی",
      heroDesc: "جلسات کوچینگ تخصصی، آموزش‌های کاربردی و محتوای الهام‌بخش برای ساختن نسخه‌ای آگاه‌تر و توانمندتر از خودتان.",
      email: "hello@coachhashemi.com"
    },
    stats: [
      { value: "۱۲۰۰+", label: "جلسه برگزار شده" },
      { value: "۸۵۰+", label: "مراجع همراه" },
      { value: "۲۵+", label: "آموزش کاربردی" },
      { value: "۱۸۰+", label: "مقاله و تحلیل" }
    ],
    sections: {
      coaching: true, mentoring: false, workshops: false, groupCoaching: false,
      trainings: true, articles: true, filmAnalysis: true, booking: true
    },
    features: [
      { icon: "🛡️", title: "فضای امن", desc: "بدون قضاوت و محرمانه" },
      { icon: "🎓", title: "رویکرد علمی", desc: "بر پایه روش‌های اثبات‌شده" },
      { icon: "🤝", title: "همراهی واقعی", desc: "در مسیر رشد و تغییر پایدار" },
      { icon: "📈", title: "نتایج ملموس", desc: "تمرکز بر اقدام و تغییرات قابل اندازه‌گیری" }
    ],
    theme: {
      roseGold: "#E8B4A0", dustyBlue: "#546A7B", warmIvory: "#FAF7F4",
      charcoal: "#2E3138", softGray: "#687280"
    },
    availableSlots: {},
    password: "coach2026"
  },

  _headers() {
    const h = { "Content-Type": "application/json" };
    const t = this.token || sessionStorage.getItem("ch_token");
    if (t) h["Authorization"] = "Bearer " + t;
    return h;
  },

  async api(path, opts = {}) {
    try {
      const res = await fetch(this.API + path, {
        ...opts,
        headers: { ...this._headers(), ...(opts.headers || {}) }
      });
      if (res.status === 401) {
        this.token = null;
        sessionStorage.removeItem("ch_token");
        sessionStorage.removeItem("ch_admin");
      }
      const data = await res.json().catch(() => ({}));
      if (!res.ok) throw new Error(data.error || "خطای سرور");
      return data;
    } catch (e) {
      if (e.message === "Failed to fetch" || e.name === "TypeError") {
        throw new Error("OFFLINE");
      }
      throw e;
    }
  },

  // ── Config ──
  async getConfigAsync() {
    try {
      const cfg = await this.api("/api/config");
      return { ...this.defaultConfig, ...cfg, sections: { ...this.defaultConfig.sections, ...(cfg.sections || {}) } };
    } catch (e) {
      return this.getConfigLocal();
    }
  },

  getConfig() {
    // Sync fallback for public pages
    return this.getConfigLocal();
  },

  getConfigLocal() {
    try {
      const saved = localStorage.getItem("ch_config");
      if (saved) {
        const parsed = JSON.parse(saved);
        return { ...this.defaultConfig, ...parsed, sections: { ...this.defaultConfig.sections, ...(parsed.sections || {}) } };
      }
    } catch (e) {}
    return JSON.parse(JSON.stringify(this.defaultConfig));
  },

  async saveConfigAsync(cfg) {
    try {
      await this.api("/api/config", { method: "PUT", body: JSON.stringify(cfg) });
      localStorage.setItem("ch_config", JSON.stringify(cfg)); // cache
      localStorage.setItem("ch_config_updated", Date.now().toString());
      return true;
    } catch (e) {
      if (e.message === "OFFLINE") {
        this.saveConfigLocal(cfg);
        return true;
      }
      throw e;
    }
  },

  saveConfig(cfg) {
    this.saveConfigLocal(cfg);
  },

  saveConfigLocal(cfg) {
    localStorage.setItem("ch_config", JSON.stringify(cfg));
    localStorage.setItem("ch_config_updated", Date.now().toString());
  },

  // ── Bookings ──
  async getBookingsAsync(status) {
    try {
      const q = status && status !== "all" ? "?status=" + status : "";
      return await this.api("/api/bookings" + q);
    } catch (e) {
      return this.getBookingsLocal();
    }
  },

  getBookings() {
    return this.getBookingsLocal();
  },

  getBookingsLocal() {
    try { return JSON.parse(localStorage.getItem("ch_bookings") || "[]"); }
    catch (e) { return []; }
  },

  async addBookingAsync(b) {
    try {
      return await this.api("/api/bookings", { method: "POST", body: JSON.stringify(b) });
    } catch (e) {
      if (e.message === "OFFLINE") return this.addBookingLocal(b);
      throw e;
    }
  },

  addBooking(b) {
    return this.addBookingLocal(b);
  },

  addBookingLocal(b) {
    const list = this.getBookingsLocal();
    b.id = Date.now().toString();
    b.createdAt = new Date().toISOString();
    b.status = "pending";
    list.unshift(b);
    localStorage.setItem("ch_bookings", JSON.stringify(list));
    return b;
  },

  async updateBookingStatusAsync(id, status) {
    try {
      await this.api("/api/bookings/" + id + "/status", {
        method: "PATCH", body: JSON.stringify({ status })
      });
    } catch (e) {
      if (e.message === "OFFLINE") this.updateBookingStatusLocal(id, status);
      else throw e;
    }
  },

  updateBookingStatus(id, status) {
    this.updateBookingStatusLocal(id, status);
  },

  updateBookingStatusLocal(id, status) {
    const list = this.getBookingsLocal();
    const i = list.findIndex(x => String(x.id) === String(id));
    if (i >= 0) { list[i].status = status; localStorage.setItem("ch_bookings", JSON.stringify(list)); }
  },

  // ── Slots ──
  async getSlotsAsync() {
    try { return await this.api("/api/slots"); }
    catch (e) { return (this.getConfigLocal().availableSlots) || {}; }
  },

  async addSlotAsync(date, time) {
    try {
      await this.api("/api/slots", { method: "POST", body: JSON.stringify({ date, time }) });
    } catch (e) {
      if (e.message === "OFFLINE") {
        const cfg = this.getConfigLocal();
        if (!cfg.availableSlots) cfg.availableSlots = {};
        if (!cfg.availableSlots[date]) cfg.availableSlots[date] = [];
        if (!cfg.availableSlots[date].includes(time)) cfg.availableSlots[date].push(time);
        this.saveConfigLocal(cfg);
      } else throw e;
    }
  },

  async removeSlotAsync(date, time) {
    try {
      await this.api("/api/slots", { method: "DELETE", body: JSON.stringify({ date, time }) });
    } catch (e) {
      if (e.message === "OFFLINE") {
        const cfg = this.getConfigLocal();
        if (cfg.availableSlots && cfg.availableSlots[date]) {
          cfg.availableSlots[date] = cfg.availableSlots[date].filter(t => t !== time);
          if (!cfg.availableSlots[date].length) delete cfg.availableSlots[date];
          this.saveConfigLocal(cfg);
        }
      } else throw e;
    }
  },

  // ── Auth ──
  async loginAsync(pass) {
    try {
      const data = await this.api("/api/login", {
        method: "POST", body: JSON.stringify({ password: pass })
      });
      this.token = data.token;
      sessionStorage.setItem("ch_token", data.token);
      sessionStorage.setItem("ch_admin", "1");
      return true;
    } catch (e) {
      if (e.message === "OFFLINE") {
        // local fallback
        const cfg = this.getConfigLocal();
        if (pass === cfg.password || pass === "coach2026") {
          sessionStorage.setItem("ch_admin", "1");
          return true;
        }
        return false;
      }
      return false;
    }
  },

  login(pass) {
    // sync fallback
    const cfg = this.getConfigLocal();
    if (pass === cfg.password || pass === "coach2026") {
      sessionStorage.setItem("ch_admin", "1");
      return true;
    }
    return false;
  },

  async logoutAsync() {
    try { await this.api("/api/logout", { method: "POST" }); } catch (e) {}
    this.token = null;
    sessionStorage.removeItem("ch_token");
    sessionStorage.removeItem("ch_admin");
  },

  logout() {
    this.token = null;
    sessionStorage.removeItem("ch_token");
    sessionStorage.removeItem("ch_admin");
  },

  isLoggedIn() {
    return sessionStorage.getItem("ch_admin") === "1";
  },

  async changePasswordAsync(newPass) {
    try {
      await this.api("/api/password", { method: "PUT", body: JSON.stringify({ password: newPass }) });
    } catch (e) {
      if (e.message === "OFFLINE") {
        const cfg = this.getConfigLocal();
        cfg.password = newPass;
        this.saveConfigLocal(cfg);
      } else throw e;
    }
  },

  async getStatsAsync() {
    try { return await this.api("/api/stats"); }
    catch (e) {
      const list = this.getBookingsLocal();
      return {
        total: list.length,
        pending: list.filter(b => b.status === "pending").length,
        approved: list.filter(b => b.status === "approved").length
      };
    }
  },

  // Detect if API is available
  async checkApi() {
    try {
      await this.api("/api/health");
      return true;
    } catch (e) {
      return false;
    }
  }
};



  // ── Payments ──
  async addPaymentAsync(data) {
    try {
      return await this.api("/api/payments", { method: "POST", body: JSON.stringify(data) });
    } catch (e) {
      if (e.message === "OFFLINE") {
        const list = JSON.parse(localStorage.getItem("ch_payments") || "[]");
        data.id = Date.now().toString(); data.status = "pending"; data.created_at = new Date().toISOString();
        list.unshift(data); localStorage.setItem("ch_payments", JSON.stringify(list));
        return data;
      }
      throw e;
    }
  },
  async getPaymentsAsync() {
    try { return await this.api("/api/payments"); }
    catch (e) { return JSON.parse(localStorage.getItem("ch_payments") || "[]"); }
  },
  async updatePaymentStatusAsync(id, status) {
    try {
      await this.api("/api/payments/" + id + "/status", { method: "PATCH", body: JSON.stringify({ status }) });
    } catch (e) { if (e.message !== "OFFLINE") throw e; }
  },

  // ── Sessions ──
  async addSessionAsync(data) {
    try {
      return await this.api("/api/sessions", { method: "POST", body: JSON.stringify(data) });
    } catch (e) {
      if (e.message === "OFFLINE") {
        const list = JSON.parse(localStorage.getItem("ch_sessions") || "[]");
        data.id = Date.now().toString(); data.status = "scheduled";
        list.unshift(data); localStorage.setItem("ch_sessions", JSON.stringify(list));
        return data;
      }
      throw e;
    }
  },
  async getSessionsAsync() {
    try { return await this.api("/api/sessions"); }
    catch (e) { return JSON.parse(localStorage.getItem("ch_sessions") || "[]"); }
  },
  async testNotifyAsync(channel, to) {
    return await this.api("/api/notify/test", { method: "POST", body: JSON.stringify({ channel, to }) });
  },
  async getNotifyLogAsync() {
    try { return await this.api("/api/notify/log"); }
    catch (e) { return []; }
  },

// Restore token on load
if (typeof sessionStorage !== "undefined") {
  CH.token = sessionStorage.getItem("ch_token");
}
