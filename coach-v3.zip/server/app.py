
#!/usr/bin/env python3
"""
CoachHashemi API Server
SQLite + REST API + Email/SMS notifications
"""
import os
import sys
import json
import sqlite3
import hashlib
import secrets
import smtplib
import urllib.request
import urllib.parse
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from datetime import datetime
from functools import wraps

import site
_sp = [
    "/root/.local/lib/python3.12/site-packages",
    site.getusersitepackages() if hasattr(site, "getusersitepackages") else "",
]
for _p in _sp:
    if _p and _p not in sys.path:
        sys.path.insert(0, _p)


import site
sys.path.insert(0, site.getusersitepackages())
for p in ["/root/.local/lib/python3.12/site-packages",
          os.path.expanduser("~/.local/lib/python3.12/site-packages")]:
    if p not in sys.path:
        sys.path.insert(0, p)

from flask import Flask, request, jsonify, send_from_directory, g
from flask_cors import CORS

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DB_PATH = os.environ.get("DB_PATH", os.path.join("/tmp", "coachhashemi.db"))
STATIC_DIR = os.path.dirname(BASE_DIR)

app = Flask(__name__, static_folder=None)
CORS(app, supports_credentials=True)

# ─── Database ───────────────────────────────────────────────

def get_db():
    if "db" not in g:
        g.db = sqlite3.connect(DB_PATH)
        g.db.row_factory = sqlite3.Row
        g.db.execute("PRAGMA foreign_keys = ON")
    return g.db

@app.teardown_appcontext
def close_db(exc):
    db = g.pop("db", None)
    if db is not None:
        db.close()

def init_db():
    db = sqlite3.connect(DB_PATH)
    db.executescript("""
    CREATE TABLE IF NOT EXISTS settings (
        key TEXT PRIMARY KEY,
        value TEXT NOT NULL,
        updated_at TEXT DEFAULT (datetime('now'))
    );

    CREATE TABLE IF NOT EXISTS bookings (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        phone TEXT NOT NULL,
        email TEXT,
        type TEXT,
        goal TEXT,
        status TEXT DEFAULT 'pending',
        created_at TEXT DEFAULT (datetime('now')),
        updated_at TEXT DEFAULT (datetime('now'))
    );

    CREATE TABLE IF NOT EXISTS slots (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        date TEXT NOT NULL,
        time TEXT NOT NULL,
        UNIQUE(date, time)
    );

    CREATE TABLE IF NOT EXISTS admin (
        id INTEGER PRIMARY KEY CHECK (id = 1),
        password_hash TEXT NOT NULL,
        token TEXT
    );

    CREATE TABLE IF NOT EXISTS payments (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        booking_id INTEGER,
        client_name TEXT,
        client_phone TEXT,
        amount INTEGER NOT NULL,
        method TEXT,
        ref_code TEXT,
        note TEXT,
        status TEXT DEFAULT 'pending',
        created_at TEXT DEFAULT (datetime('now')),
        FOREIGN KEY (booking_id) REFERENCES bookings(id)
    );

    CREATE TABLE IF NOT EXISTS sessions (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        client_name TEXT NOT NULL,
        client_phone TEXT NOT NULL,
        session_date TEXT,
        session_time TEXT,
        topic TEXT,
        note TEXT,
        status TEXT DEFAULT 'scheduled',
        created_at TEXT DEFAULT (datetime('now'))
    );

    CREATE TABLE IF NOT EXISTS notification_log (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        channel TEXT,
        recipient TEXT,
        subject TEXT,
        body TEXT,
        status TEXT,
        created_at TEXT DEFAULT (datetime('now'))
    );
    """)

    cur = db.execute("SELECT id FROM admin WHERE id = 1")
    if not cur.fetchone():
        pw_hash = hashlib.sha256("coach2026".encode()).hexdigest()
        db.execute("INSERT INTO admin (id, password_hash) VALUES (1, ?)", (pw_hash,))

    cur = db.execute("SELECT key FROM settings WHERE key = 'config'")
    if not cur.fetchone():
        default = {
            "site": {
                "brandName": "کوچ هاشمی",
                "tagline": "Conscious Growth",
                "heroTitle": "همراه شما در مسیر",
                "heroHighlight": "رشد و تحول فردی",
                "heroDesc": "جلسات کوچینگ تخصصی، آموزش‌های کاربردی و محتوای الهام‌بخش برای ساختن نسخه‌ای آگاه‌تر و توانمندتر از خودتان.",
                "email": "hello@coachhashemi.com",
                "logoSize": 72
            },
            "stats": [
                {"value": "۱۲۰۰+", "label": "جلسه برگزار شده"},
                {"value": "۸۵۰+", "label": "مراجع همراه"},
                {"value": "۲۵+", "label": "آموزش کاربردی"},
                {"value": "۱۸۰+", "label": "مقاله و تحلیل"}
            ],
            "sections": {
                "coaching": True, "mentoring": False, "workshops": False,
                "groupCoaching": False, "trainings": True, "articles": True,
                "filmAnalysis": True, "booking": True
            },
            "features": [
                {"icon": "🛡️", "title": "فضای امن", "desc": "بدون قضاوت و محرمانه"},
                {"icon": "🎓", "title": "رویکرد علمی", "desc": "بر پایه روش‌های اثبات‌شده"},
                {"icon": "🤝", "title": "همراهی واقعی", "desc": "در مسیر رشد و تغییر پایدار"},
                {"icon": "📈", "title": "نتایج ملموس", "desc": "تمرکز بر اقدام و تغییرات قابل اندازه‌گیری"}
            ],
            "theme": {
                "roseGold": "#E8B4A0", "dustyBlue": "#546A7B",
                "warmIvory": "#FAF7F4", "charcoal": "#2E3138", "softGray": "#687280"
            },
            "notify": {
                "coach_phone": "",
                "coach_email": "",
                "sms_enabled": False,
                "email_enabled": False,
                "notify_on_booking": True,
                "notify_on_payment": True,
                "notify_on_session": True,
                "notify_client": True
            },
            "sms": {
                "provider": "kavenegar",
                "api_key": "",
                "sender": ""
            },
            "smtp": {
                "host": "smtp.gmail.com",
                "port": 587,
                "user": "",
                "password": "",
                "from_name": "کوچ هاشمی"
            },
            "gateway": {
                "provider": "zarinpal",
                "enabled": False,
                "merchant_id": "",
                "sandbox": True,
                "callback_url": ""
            }
        }
        db.execute("INSERT INTO settings (key, value) VALUES ('config', ?)",
                   (json.dumps(default, ensure_ascii=False),))

    cur = db.execute("SELECT COUNT(*) FROM slots")
    if cur.fetchone()[0] == 0:
        samples = [
            ("1405-02-16", "09:00"), ("1405-02-16", "10:00"), ("1405-02-16", "11:00"),
            ("1405-02-17", "10:00"), ("1405-02-17", "14:00"),
            ("1405-02-18", "09:00"), ("1405-02-18", "11:00"), ("1405-02-18", "15:00"),
        ]
        db.executemany("INSERT OR IGNORE INTO slots (date, time) VALUES (?, ?)", samples)

    db.commit()
    db.close()
    print(f"Database initialized: {DB_PATH}")

def load_config(db=None):
    if db is None:
        db = get_db()
    row = db.execute("SELECT value FROM settings WHERE key = 'config'").fetchone()
    return json.loads(row["value"]) if row else {}

def save_config_dict(cfg, db=None):
    if db is None:
        db = get_db()
    db.execute(
        "INSERT INTO settings (key, value, updated_at) VALUES ('config', ?, datetime('now')) "
        "ON CONFLICT(key) DO UPDATE SET value = excluded.value, updated_at = excluded.updated_at",
        (json.dumps(cfg, ensure_ascii=False),)
    )
    db.commit()

# ─── Notifications ──────────────────────────────────────────

def log_notification(channel, recipient, subject, body, status):
    try:
        db = get_db()
        db.execute(
            "INSERT INTO notification_log (channel, recipient, subject, body, status) VALUES (?,?,?,?,?)",
            (channel, recipient, subject, body, status)
        )
        db.commit()
    except Exception:
        pass

def send_email(to, subject, body_text, cfg=None):
    if cfg is None:
        cfg = load_config()
    smtp = cfg.get("smtp") or {}
    notify = cfg.get("notify") or {}
    if not notify.get("email_enabled") or not smtp.get("user") or not smtp.get("password"):
        log_notification("email", to, subject, body_text, "skipped_no_config")
        return False, "email not configured"
    try:
        msg = MIMEMultipart()
        msg["From"] = f"{smtp.get('from_name', 'کوچ هاشمی')} <{smtp['user']}>"
        msg["To"] = to
        msg["Subject"] = subject
        msg.attach(MIMEText(body_text, "plain", "utf-8"))
        with smtplib.SMTP(smtp.get("host", "smtp.gmail.com"), int(smtp.get("port", 587))) as server:
            server.starttls()
            server.login(smtp["user"], smtp["password"])
            server.sendmail(smtp["user"], to, msg.as_string())
        log_notification("email", to, subject, body_text, "sent")
        return True, "sent"
    except Exception as e:
        log_notification("email", to, subject, body_text, f"error:{e}")
        return False, str(e)

def send_sms(phone, text, cfg=None):
    if cfg is None:
        cfg = load_config()
    sms = cfg.get("sms") or {}
    notify = cfg.get("notify") or {}
    if not notify.get("sms_enabled") or not sms.get("api_key"):
        log_notification("sms", phone, "", text, "skipped_no_config")
        return False, "sms not configured"
    provider = (sms.get("provider") or "kavenegar").lower()
    try:
        if provider == "kavenegar":
            # https://api.kavenegar.com/v1/{API-KEY}/sms/send.json
            key = sms["api_key"]
            sender = sms.get("sender") or ""
            params = urllib.parse.urlencode({
                "receptor": phone,
                "message": text,
                "sender": sender
            })
            url = f"https://api.kavenegar.com/v1/{key}/sms/send.json?{params}"
            with urllib.request.urlopen(url, timeout=15) as resp:
                result = resp.read().decode()
            log_notification("sms", phone, "", text, "sent")
            return True, result
        elif provider == "ghasedak":
            # Ghasedak API
            data = urllib.parse.urlencode({
                "receptor": phone,
                "message": text,
                "linenumber": sms.get("sender") or ""
            }).encode()
            req = urllib.request.Request(
                "https://api.ghasedak.me/v2/sms/send/simple",
                data=data,
                headers={"apikey": sms["api_key"]}
            )
            with urllib.request.urlopen(req, timeout=15) as resp:
                result = resp.read().decode()
            log_notification("sms", phone, "", text, "sent")
            return True, result
        else:
            log_notification("sms", phone, "", text, "unknown_provider")
            return False, "unknown provider"
    except Exception as e:
        log_notification("sms", phone, "", text, f"error:{e}")
        return False, str(e)

def notify_coach(subject, body, cfg=None):
    if cfg is None:
        cfg = load_config()
    notify = cfg.get("notify") or {}
    results = []
    if notify.get("coach_email"):
        ok, msg = send_email(notify["coach_email"], subject, body, cfg)
        results.append(("email", ok, msg))
    if notify.get("coach_phone"):
        ok, msg = send_sms(notify["coach_phone"], body[:200], cfg)
        results.append(("sms", ok, msg))
    return results

def notify_client(phone, email, subject, body, cfg=None):
    if cfg is None:
        cfg = load_config()
    notify = cfg.get("notify") or {}
    if not notify.get("notify_client"):
        return []
    results = []
    if email:
        ok, msg = send_email(email, subject, body, cfg)
        results.append(("email", ok, msg))
    if phone:
        ok, msg = send_sms(phone, body[:200], cfg)
        results.append(("sms", ok, msg))
    return results

# ─── Auth ───────────────────────────────────────────────────

def require_auth(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        token = request.headers.get("Authorization", "").replace("Bearer ", "")
        if not token:
            return jsonify({"error": "unauthorized"}), 401
        db = get_db()
        row = db.execute("SELECT token FROM admin WHERE id = 1").fetchone()
        if not row or row["token"] != token:
            return jsonify({"error": "unauthorized"}), 401
        return f(*args, **kwargs)
    return decorated

# ─── API Routes ─────────────────────────────────────────────

@app.route("/api/health")
def health():
    return jsonify({"status": "ok", "db": os.path.exists(DB_PATH)})

@app.route("/api/login", methods=["POST"])
def login():
    data = request.get_json() or {}
    password = data.get("password", "")
    # رمز پایدار از Environment Variable (روی Render حفظ می‌شود)
    env_pw = os.environ.get("ADMIN_PASSWORD", "").strip()
    ok = False
    if env_pw and password == env_pw:
        ok = True
    else:
        pw_hash = hashlib.sha256(password.encode()).hexdigest()
        db = get_db()
        row = db.execute("SELECT password_hash FROM admin WHERE id = 1").fetchone()
        if row and row["password_hash"] == pw_hash:
            ok = True
    if not ok:
        return jsonify({"error": "رمز عبور اشتباه است"}), 401
    db = get_db()
    token = secrets.token_hex(32)
    db.execute("UPDATE admin SET token = ? WHERE id = 1", (token,))
    db.commit()
    return jsonify({"token": token, "ok": True})

@app.route("/api/logout", methods=["POST"])
@require_auth
def logout():
    db = get_db()
    db.execute("UPDATE admin SET token = NULL WHERE id = 1")
    db.commit()
    return jsonify({"ok": True})

@app.route("/api/config", methods=["GET"])
def get_config():
    db = get_db()
    config = load_config(db)
    # hide secrets from public
    public = json.loads(json.dumps(config))
    if "smtp" in public:
        public["smtp"] = {k: ("***" if k == "password" and v else v) for k, v in public["smtp"].items()}
    if "sms" in public:
        public["sms"] = {k: ("***" if k == "api_key" and v else v) for k, v in public["sms"].items()}
    if "gateway" in public:
        public["gateway"] = {k: ("***" if k == "merchant_id" and v else v) for k, v in public["gateway"].items()}
        public["gateway"]["enabled"] = (config.get("gateway") or {}).get("enabled", False)
        public["gateway"]["sandbox"] = (config.get("gateway") or {}).get("sandbox", True)
        public["gateway"]["provider"] = (config.get("gateway") or {}).get("provider", "zarinpal")
    slots_rows = db.execute("SELECT date, time FROM slots ORDER BY date, time").fetchall()
    available = {}
    for r in slots_rows:
        available.setdefault(r["date"], []).append(r["time"])
    public["availableSlots"] = available
    return jsonify(public)

@app.route("/api/config", methods=["PUT"])
@require_auth
def save_config():
    data = request.get_json() or {}
    data.pop("availableSlots", None)
    data.pop("password", None)
    # merge secrets: if client sent ***, keep old
    db = get_db()
    old = load_config(db)
    if data.get("smtp", {}).get("password") == "***":
        data.setdefault("smtp", {})["password"] = (old.get("smtp") or {}).get("password", "")
    if data.get("sms", {}).get("api_key") == "***":
        data.setdefault("sms", {})["api_key"] = (old.get("sms") or {}).get("api_key", "")
    if data.get("gateway", {}).get("merchant_id") == "***":
        data.setdefault("gateway", {})["merchant_id"] = (old.get("gateway") or {}).get("merchant_id", "")
    # deep merge notify/smtp/sms
    for key in ("notify", "smtp", "sms", "site", "theme", "sections"):
        if key in data and key in old and isinstance(old[key], dict):
            merged = {**old[key], **data[key]}
            data[key] = merged
    full = {**old, **data}
    save_config_dict(full, db)
    return jsonify({"ok": True})

@app.route("/api/bookings", methods=["GET"])
@require_auth
def list_bookings():
    status = request.args.get("status")
    db = get_db()
    if status and status != "all":
        rows = db.execute(
            "SELECT * FROM bookings WHERE status = ? ORDER BY created_at DESC", (status,)
        ).fetchall()
    else:
        rows = db.execute("SELECT * FROM bookings ORDER BY created_at DESC").fetchall()
    return jsonify([dict(r) for r in rows])

@app.route("/api/bookings", methods=["POST"])
def create_booking():
    data = request.get_json() or {}
    name = (data.get("name") or "").strip()
    phone = (data.get("phone") or "").strip()
    if not name or not phone:
        return jsonify({"error": "نام و موبایل الزامی است"}), 400
    db = get_db()
    cur = db.execute(
        "INSERT INTO bookings (name, phone, email, type, goal) VALUES (?, ?, ?, ?, ?)",
        (name, phone, data.get("email"), data.get("type"), data.get("goal"))
    )
    db.commit()
    bid = cur.lastrowid
    cfg = load_config(db)
    notify = cfg.get("notify") or {}
    if notify.get("notify_on_booking"):
        body_coach = f"رزرو جدید از {name}\nموبایل: {phone}\nنوع: {data.get('type') or '-'}\nهدف: {data.get('goal') or '-'}"
        notify_coach("رزرو جدید – کوچ هاشمی", body_coach, cfg)
        if notify.get("notify_client"):
            body_client = f"سلام {name} عزیز،\nدرخواست رزرو شما در کوچ هاشمی ثبت شد.\nبه زودی با شما هماهنگ می‌کنیم."
            notify_client(phone, data.get("email"), "ثبت رزرو – کوچ هاشمی", body_client, cfg)
    return jsonify({"ok": True, "id": bid}), 201

@app.route("/api/bookings/<int:bid>/status", methods=["PATCH"])
@require_auth
def update_booking_status(bid):
    data = request.get_json() or {}
    status = data.get("status")
    if status not in ("pending", "approved", "rejected"):
        return jsonify({"error": "وضعیت نامعتبر"}), 400
    db = get_db()
    row = db.execute("SELECT * FROM bookings WHERE id = ?", (bid,)).fetchone()
    if not row:
        return jsonify({"error": "یافت نشد"}), 404
    db.execute(
        "UPDATE bookings SET status = ?, updated_at = datetime('now') WHERE id = ?",
        (status, bid)
    )
    db.commit()
    cfg = load_config(db)
    status_fa = {"approved": "تأیید شد", "rejected": "رد شد", "pending": "در انتظار"}[status]
    body = f"وضعیت رزرو شما ({row['name']}) به «{status_fa}» تغییر کرد.\n— کوچ هاشمی"
    notify_client(row["phone"], row["email"], f"وضعیت رزرو – {status_fa}", body, cfg)
    return jsonify({"ok": True})

@app.route("/api/slots", methods=["GET"])
def list_slots():
    db = get_db()
    rows = db.execute("SELECT date, time FROM slots ORDER BY date, time").fetchall()
    available = {}
    for r in rows:
        available.setdefault(r["date"], []).append(r["time"])
    return jsonify(available)

@app.route("/api/slots", methods=["POST"])
@require_auth
def add_slot():
    data = request.get_json() or {}
    date = (data.get("date") or "").strip()
    time = (data.get("time") or "").strip()
    if not date or not time:
        return jsonify({"error": "تاریخ و ساعت الزامی است"}), 400
    db = get_db()
    try:
        db.execute("INSERT INTO slots (date, time) VALUES (?, ?)", (date, time))
        db.commit()
    except sqlite3.IntegrityError:
        return jsonify({"error": "این زمان قبلاً ثبت شده"}), 409
    return jsonify({"ok": True}), 201

@app.route("/api/slots", methods=["DELETE"])
@require_auth
def remove_slot():
    data = request.get_json() or {}
    db = get_db()
    db.execute("DELETE FROM slots WHERE date = ? AND time = ?", (data.get("date"), data.get("time")))
    db.commit()
    return jsonify({"ok": True})

@app.route("/api/password", methods=["PUT"])
@require_auth
def change_password():
    data = request.get_json() or {}
    new_pass = data.get("password", "")
    if len(new_pass) < 4:
        return jsonify({"error": "رمز حداقل ۴ کاراکتر"}), 400
    pw_hash = hashlib.sha256(new_pass.encode()).hexdigest()
    db = get_db()
    db.execute("UPDATE admin SET password_hash = ? WHERE id = 1", (pw_hash,))
    db.commit()
    return jsonify({"ok": True})

@app.route("/api/stats", methods=["GET"])
@require_auth
def stats():
    db = get_db()
    total = db.execute("SELECT COUNT(*) FROM bookings").fetchone()[0]
    pending = db.execute("SELECT COUNT(*) FROM bookings WHERE status='pending'").fetchone()[0]
    approved = db.execute("SELECT COUNT(*) FROM bookings WHERE status='approved'").fetchone()[0]
    payments = db.execute("SELECT COUNT(*) FROM payments").fetchone()[0]
    sessions = db.execute("SELECT COUNT(*) FROM sessions").fetchone()[0]
    return jsonify({
        "total": total, "pending": pending, "approved": approved,
        "payments": payments, "sessions": sessions
    })

# ─── Payments ───────────────────────────────────────────────

@app.route("/api/payments", methods=["GET"])
@require_auth
def list_payments():
    db = get_db()
    rows = db.execute("SELECT * FROM payments ORDER BY created_at DESC").fetchall()
    return jsonify([dict(r) for r in rows])

@app.route("/api/payments", methods=["POST"])
def create_payment():
    """Public: client reports a payment"""
    data = request.get_json() or {}
    amount = data.get("amount")
    phone = (data.get("client_phone") or data.get("phone") or "").strip()
    name = (data.get("client_name") or data.get("name") or "").strip()
    if not amount or not phone:
        return jsonify({"error": "مبلغ و موبایل الزامی است"}), 400
    try:
        amount = int(str(amount).replace(",", "").replace("،", ""))
    except ValueError:
        return jsonify({"error": "مبلغ نامعتبر"}), 400
    db = get_db()
    cur = db.execute(
        "INSERT INTO payments (booking_id, client_name, client_phone, amount, method, ref_code, note) "
        "VALUES (?, ?, ?, ?, ?, ?, ?)",
        (data.get("booking_id"), name, phone, amount,
         data.get("method"), data.get("ref_code"), data.get("note"))
    )
    db.commit()
    pid = cur.lastrowid
    cfg = load_config(db)
    notify = cfg.get("notify") or {}
    if notify.get("notify_on_payment"):
        body = f"اعلام واریزی جدید\nنام: {name or '-'}\nموبایل: {phone}\nمبلغ: {amount:,} تومان\nپیگیری: {data.get('ref_code') or '-'}"
        notify_coach("واریزی جدید – کوچ هاشمی", body, cfg)
        body_c = f"سلام {name or ''} عزیز،\nاعلام واریزی شما به مبلغ {amount:,} تومان ثبت شد و در حال بررسی است.\n— کوچ هاشمی"
        notify_client(phone, data.get("email"), "ثبت واریزی – کوچ هاشمی", body_c, cfg)
    return jsonify({"ok": True, "id": pid}), 201

@app.route("/api/payments/<int:pid>/status", methods=["PATCH"])
@require_auth
def update_payment_status(pid):
    data = request.get_json() or {}
    status = data.get("status")
    if status not in ("pending", "confirmed", "rejected"):
        return jsonify({"error": "وضعیت نامعتبر"}), 400
    db = get_db()
    row = db.execute("SELECT * FROM payments WHERE id = ?", (pid,)).fetchone()
    if not row:
        return jsonify({"error": "یافت نشد"}), 404
    db.execute("UPDATE payments SET status = ? WHERE id = ?", (status, pid))
    db.commit()
    status_fa = {"confirmed": "تأیید شد", "rejected": "رد شد", "pending": "در انتظار"}[status]
    body = f"وضعیت واریزی شما ({row['amount']:,} تومان) به «{status_fa}» تغییر کرد.\n— کوچ هاشمی"
    notify_client(row["client_phone"], None, f"وضعیت واریزی – {status_fa}", body, load_config(db))
    return jsonify({"ok": True})

# ─── Sessions (client-reported) ─────────────────────────────

@app.route("/api/sessions", methods=["GET"])
@require_auth
def list_sessions():
    db = get_db()
    rows = db.execute("SELECT * FROM sessions ORDER BY created_at DESC").fetchall()
    return jsonify([dict(r) for r in rows])

@app.route("/api/sessions", methods=["POST"])
def create_session():
    """Public: client registers a session request"""
    data = request.get_json() or {}
    name = (data.get("client_name") or data.get("name") or "").strip()
    phone = (data.get("client_phone") or data.get("phone") or "").strip()
    if not name or not phone:
        return jsonify({"error": "نام و موبایل الزامی است"}), 400
    db = get_db()
    cur = db.execute(
        "INSERT INTO sessions (client_name, client_phone, session_date, session_time, topic, note) "
        "VALUES (?, ?, ?, ?, ?, ?)",
        (name, phone, data.get("session_date"), data.get("session_time"),
         data.get("topic"), data.get("note"))
    )
    db.commit()
    sid = cur.lastrowid
    cfg = load_config(db)
    notify = cfg.get("notify") or {}
    if notify.get("notify_on_session"):
        body = f"ثبت جلسه از طرف مراجع\nنام: {name}\nموبایل: {phone}\nتاریخ: {data.get('session_date') or '-'}\nساعت: {data.get('session_time') or '-'}\nموضوع: {data.get('topic') or '-'}"
        notify_coach("ثبت جلسه جدید – کوچ هاشمی", body, cfg)
        body_c = f"سلام {name} عزیز،\nدرخواست جلسه شما ثبت شد.\nتاریخ: {data.get('session_date') or '-'}\nساعت: {data.get('session_time') or '-'}\n— کوچ هاشمی"
        notify_client(phone, data.get("email"), "ثبت جلسه – کوچ هاشمی", body_c, cfg)
    return jsonify({"ok": True, "id": sid}), 201

@app.route("/api/sessions/<int:sid>/status", methods=["PATCH"])
@require_auth
def update_session_status(sid):
    data = request.get_json() or {}
    status = data.get("status")
    if status not in ("scheduled", "done", "cancelled"):
        return jsonify({"error": "وضعیت نامعتبر"}), 400
    db = get_db()
    db.execute("UPDATE sessions SET status = ? WHERE id = ?", (status, sid))
    db.commit()
    return jsonify({"ok": True})

# ─── Notification test & log ────────────────────────────────

@app.route("/api/notify/test", methods=["POST"])
@require_auth
def test_notify():
    data = request.get_json() or {}
    channel = data.get("channel", "email")
    cfg = load_config()
    if channel == "email":
        to = data.get("to") or (cfg.get("notify") or {}).get("coach_email")
        if not to:
            return jsonify({"error": "ایمیل مقصد مشخص نیست"}), 400
        ok, msg = send_email(to, "تست اعلان – کوچ هاشمی", "این یک پیام تست است.", cfg)
    else:
        to = data.get("to") or (cfg.get("notify") or {}).get("coach_phone")
        if not to:
            return jsonify({"error": "شماره مقصد مشخص نیست"}), 400
        ok, msg = send_sms(to, "تست اعلان کوچ هاشمی", cfg)
    return jsonify({"ok": ok, "message": msg})

@app.route("/api/notify/log", methods=["GET"])
@require_auth
def notify_log():
    db = get_db()
    rows = db.execute(
        "SELECT * FROM notification_log ORDER BY created_at DESC LIMIT 50"
    ).fetchall()
    return jsonify([dict(r) for r in rows])


# ─── Online Payment (Zarinpal) ──────────────────────────────

def _zarinpal_urls(sandbox):
    if sandbox:
        return {
            "request": "https://sandbox.zarinpal.com/pg/v4/payment/request.json",
            "verify": "https://sandbox.zarinpal.com/pg/v4/payment/verify.json",
            "start": "https://sandbox.zarinpal.com/pg/StartPay/"
        }
    return {
        "request": "https://api.zarinpal.com/pg/v4/payment/request.json",
        "verify": "https://api.zarinpal.com/pg/v4/payment/verify.json",
        "start": "https://www.zarinpal.com/pg/StartPay/"
    }

@app.route("/api/pay/request", methods=["POST"])
def pay_request():
    """Start online payment — returns payment URL"""
    data = request.get_json() or {}
    try:
        amount = int(str(data.get("amount", "0")).replace(",", "").replace("،", ""))
    except ValueError:
        return jsonify({"error": "مبلغ نامعتبر"}), 400
    if amount < 1000:
        return jsonify({"error": "حداقل مبلغ ۱۰۰۰ تومان"}), 400

    name = (data.get("name") or data.get("client_name") or "").strip()
    phone = (data.get("phone") or data.get("client_phone") or "").strip()
    email = (data.get("email") or "").strip()
    description = (data.get("description") or data.get("note") or "پرداخت کوچ هاشمی").strip()

    cfg = load_config()
    gw = cfg.get("gateway") or {}
    if not gw.get("enabled") or not gw.get("merchant_id"):
        return jsonify({"error": "درگاه پرداخت فعال نیست. از پنل ادمین تنظیم کنید."}), 400

    db = get_db()
    cur = db.execute(
        "INSERT INTO payments (booking_id, client_name, client_phone, amount, method, ref_code, note, status) "
        "VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
        (data.get("booking_id"), name, phone, amount, "zarinpal", None, description, "pending")
    )
    db.commit()
    payment_id = cur.lastrowid

    # callback URL
    base = gw.get("callback_url") or request.host_url.rstrip("/")
    callback = f"{base}/api/pay/callback?pid={payment_id}"

    urls = _zarinpal_urls(gw.get("sandbox", True))
    payload = {
        "merchant_id": gw["merchant_id"],
        "amount": amount * 10,  # تومان → ریال
        "callback_url": callback,
        "description": description[:255],
        "metadata": {"mobile": phone, "email": email}
    }
    try:
        req = urllib.request.Request(
            urls["request"],
            data=json.dumps(payload).encode("utf-8"),
            headers={"Content-Type": "application/json", "Accept": "application/json"},
            method="POST"
        )
        with urllib.request.urlopen(req, timeout=20) as resp:
            result = json.loads(resp.read().decode())
    except Exception as e:
        db.execute("UPDATE payments SET status = ? WHERE id = ?", ("failed", payment_id))
        db.commit()
        return jsonify({"error": f"خطا در اتصال به درگاه: {e}"}), 502

    data_r = result.get("data") or {}
    authority = data_r.get("authority")
    code = data_r.get("code")
    if code != 100 or not authority:
        err = (result.get("errors") or data_r.get("message") or result)
        db.execute("UPDATE payments SET status = ? WHERE id = ?", ("failed", payment_id))
        db.commit()
        return jsonify({"error": "درگاه پرداخت را رد کرد", "detail": err}), 400

    db.execute("UPDATE payments SET ref_code = ? WHERE id = ?", (authority, payment_id))
    db.commit()
    pay_url = urls["start"] + authority
    return jsonify({"ok": True, "payment_id": payment_id, "url": pay_url, "authority": authority})

@app.route("/api/pay/callback", methods=["GET", "POST"])
def pay_callback():
    """Zarinpal returns user here after payment"""
    authority = request.args.get("Authority") or request.args.get("authority")
    status = request.args.get("Status") or request.args.get("status")
    pid = request.args.get("pid")

    db = get_db()
    row = None
    if pid:
        row = db.execute("SELECT * FROM payments WHERE id = ?", (pid,)).fetchone()
    if not row and authority:
        row = db.execute("SELECT * FROM payments WHERE ref_code = ?", (authority,)).fetchone()

    if not row:
        return _pay_result_page(False, "پرداخت یافت نشد")

    if status != "OK":
        db.execute("UPDATE payments SET status = ? WHERE id = ?", ("rejected", row["id"]))
        db.commit()
        return _pay_result_page(False, "پرداخت لغو شد یا ناموفق بود")

    cfg = load_config(db)
    gw = cfg.get("gateway") or {}
    urls = _zarinpal_urls(gw.get("sandbox", True))
    payload = {
        "merchant_id": gw.get("merchant_id"),
        "amount": int(row["amount"]) * 10,
        "authority": authority
    }
    try:
        req = urllib.request.Request(
            urls["verify"],
            data=json.dumps(payload).encode("utf-8"),
            headers={"Content-Type": "application/json", "Accept": "application/json"},
            method="POST"
        )
        with urllib.request.urlopen(req, timeout=20) as resp:
            result = json.loads(resp.read().decode())
    except Exception as e:
        return _pay_result_page(False, f"خطا در تأیید پرداخت: {e}")

    data_r = result.get("data") or {}
    code = data_r.get("code")
    if code in (100, 101):
        ref_id = data_r.get("ref_id") or authority
        db.execute(
            "UPDATE payments SET status = ?, ref_code = ? WHERE id = ?",
            ("confirmed", str(ref_id), row["id"])
        )
        db.commit()
        notify = cfg.get("notify") or {}
        if notify.get("notify_on_payment"):
            body = f"پرداخت آنلاین موفق\nنام: {row['client_name'] or '-'}\nموبایل: {row['client_phone'] or '-'}\nمبلغ: {row['amount']:,} تومان\nکد پیگیری: {ref_id}"
            notify_coach("پرداخت موفق – کوچ هاشمی", body, cfg)
            if row["client_phone"]:
                notify_client(row["client_phone"], None, "پرداخت موفق",
                              f"پرداخت شما به مبلغ {row['amount']:,} تومان تأیید شد.\nکد پیگیری: {ref_id}\n— کوچ هاشمی", cfg)
        return _pay_result_page(True, f"پرداخت موفق — کد پیگیری: {ref_id}")
    else:
        db.execute("UPDATE payments SET status = ? WHERE id = ?", ("rejected", row["id"]))
        db.commit()
        return _pay_result_page(False, "تأیید پرداخت ناموفق بود")

def _pay_result_page(ok, message):
    color = "#22c55e" if ok else "#ef4444"
    title = "پرداخت موفق" if ok else "پرداخت ناموفق"
    html = f"""<!DOCTYPE html><html lang="fa" dir="rtl"><head><meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>{title}</title>
<style>body{{font-family:Tahoma,sans-serif;background:#FAF7F4;display:flex;align-items:center;justify-content:center;min-height:100vh;margin:0}}
.box{{background:#fff;padding:2rem;border-radius:16px;text-align:center;max-width:360px;box-shadow:0 8px 30px rgba(0,0,0,.08)}}
h1{{color:{color};font-size:1.3rem}}p{{color:#555;line-height:1.7}}a{{display:inline-block;margin-top:1.25rem;background:#E8B4A0;color:#fff;padding:.7rem 1.4rem;border-radius:10px;text-decoration:none}}</style>
</head><body><div class="box"><h1>{title}</h1><p>{message}</p><a href="/">بازگشت به سایت</a></div></body></html>"""
    return html


# ─── Static ─────────────────────────────────────────────────

@app.route("/")
def index():
    return send_from_directory(STATIC_DIR, "index.html")

@app.route("/admin.html")
def admin_page():
    return send_from_directory(STATIC_DIR, "admin.html")

@app.route("/ch-data.js")
def ch_data():
    return send_from_directory(STATIC_DIR, "ch-data.js")

@app.route("/<path:path>")
def static_files(path):
    return send_from_directory(STATIC_DIR, path)

if __name__ == "__main__":
    init_db()
    port = int(os.environ.get("PORT", 5000))
    cert = os.path.join(BASE_DIR, "certs", "cert.pem")
    key = os.path.join(BASE_DIR, "certs", "key.pem")
    use_https = os.environ.get("USE_HTTPS", "1") == "1" and os.path.exists(cert) and os.path.exists(key)

    if use_https:
        print(f"\n  کوچ هاشمی (HTTPS) → https://0.0.0.0:{port}")
        print(f"  پنل: https://localhost:{port}/admin.html")
        print(f"  رمز: coach2026")
        print(f"  ⚠ گواهی خودامضا — در مرورگر «Advanced → Proceed» را بزنید\n")
        app.run(host="0.0.0.0", port=port, debug=False, ssl_context=(cert, key))
    else:
        print(f"\n  کوچ هاشمی API → http://0.0.0.0:{port}")
        print(f"  پنل: http://localhost:{port}/admin.html")
        print(f"  رمز: coach2026")
        print(f"  (برای HTTPS: USE_HTTPS=1 و فایل‌های certs/)\n")
        app.run(host="0.0.0.0", port=port, debug=False)
